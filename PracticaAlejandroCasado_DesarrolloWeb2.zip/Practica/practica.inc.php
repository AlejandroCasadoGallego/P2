<?php
    $SITE = dirname($_SERVER['SCRIPT_NAME']);